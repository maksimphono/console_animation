#include "include/frames.hpp"
#include "utils/check_path.cpp"
#include "utils/exec_command.cpp"
#include "utils/TerminalRestorer.cpp"
#include "utils/ThreadPool.cpp"

#include <stdlib.h>

#include "include/storage.hpp"

namespace fs = std::filesystem;

using namespace std;
using ThreadPool = threadpool_ns::ThreadPool;

#define READ_BUF_SIZE 4096

namespace frames_ns {
    vector<Frame> _frames; // array, that holds all the frames

    Timestamp::Timestamp(uint8_t h, uint8_t m, uint8_t s, uint16_t ms)
        : hours(h), minutes(m), seconds(s), miliseconds(ms) {
        this->time = this->miliseconds + (uint32_t)seconds * 1000 + (uint32_t)minutes * 60000 + (uint32_t)hours * 3600000;
    }

    Timestamp::Timestamp(uint32_t time_ms) {
        this->time = time_ms;

        this->miliseconds = this->time % 1000;
        this->seconds = (this->time / 1000) % 60;
        this->minutes = (this->time / 60000) % 60;
        this->hours = this->time / 3600000;
    }

    void Timestamp::inc(uint16_t ms) {
        this->time += (uint32_t)ms;

        this->miliseconds = this->time % 1000;
        this->seconds = (this->time / 1000) % 60;
        this->minutes = (this->time / 60000) % 60;
        this->hours = this->time / 3600000;
    }

    void limit_to_cores(uint32_t num_cores) {
        cpu_set_t mask;
        CPU_ZERO(&mask);

        // Allow the program to use only the first 'num_cores'
        for (uint32_t i = 0; i < num_cores; i++) {
            CPU_SET(i, &mask);
        }

        // Set affinity for the current process
        if (sched_setaffinity(0, sizeof(mask), &mask) == -1) {
            perror("sched_setaffinity failed");
        }
    }

    Frame pick_frame(string& path, Timestamp& ts, uint8_t size[2]) {
        exec_command_ns::CommandExecutor pick_frame_command_template("ffmpeg -loglevel -8 -ss %d:%d:%d.%03d -i %s -frames:v 1 -f image2pipe -", READ_BUF_SIZE);
        exec_command_ns::CommandExecutor convert_frame_command_template("jp2a - --size=%dx%d", READ_BUF_SIZE);
        string output = "";
        int p = -9;

        p = pick_frame_command_template.exec<int>(p, ts.hours, ts.minutes, ts.seconds, ts.miliseconds, path.c_str());
        output = convert_frame_command_template.exec<string>(p, size[0], size[1]);

        pick_frame_command_template.wait();
        convert_frame_command_template.wait();

        if (output.length() != (size_t)((size[0] + 1) * size[1])) {
            THROW_JP2A_PROGRAM_ISSUE_EXP;
        }

        return Frame(output, size, ts.time);
    }

    uint32_t get_video_duration(string& path) {
        exec_command_ns::CommandExecutor command_template("ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 %s");
        double duration = 0;
        const string output = command_template.exec<string>(-9, path.c_str());
        command_template.wait();

        if (output.length() == 0) {
            THROW_VIDEO_DURATION_EXP;
        }

        sscanf(output.c_str(), "%lf", &duration);

        return static_cast<uint32_t>(duration * 1000); // duration in miliseconds
    }

    vector<Frame>& create_frames_from_video(EnvArguments& arguments) {
        vector<Frame>& frames = _frames;

        TerminalRestorer restorer;

        if (arguments.path.empty()) {
            THROW_EMPTY_INPUT_EXP;
        }

        if (!check_path(arguments.path)) {
            THROW_INPUT_FILE_NOT_FOUND_EXP;
        }

        uint32_t* time = arguments.time;

        uint16_t inc_ms = 1000 / arguments.fps;
        uint32_t video_end_time = get_video_duration(arguments.path);
        uint32_t video_start_time = 0;
        video_end_time = (time[1] * 1000 > video_end_time)?video_end_time:(time[1] * 1000);
        video_end_time -= video_end_time % inc_ms;
        video_start_time = (time[0] * 1000 > video_end_time)?(video_end_time - 2000):(time[0] * 1000);

        Timestamp ts(video_start_time);
        limit_to_cores(arguments.cores);
        ThreadPool pool(arguments.cores);

        queue<future<Frame>> futures;

        frames.clear();

        while (ts.time < video_end_time) {
            futures.push(pool.submit(pick_frame, arguments.path, ts, arguments.size));

            ts.inc(inc_ms);
        }

        while (!futures.empty()) {
            frames.push_back(futures.front().get());
            futures.pop();
        }

        //cleanup();

        return frames;
    }

    vector<Frame>& create_frames(EnvArguments& arguments) {
        vector<Frame>& frames = _frames;

        if (arguments.loaded_from_file) {
            frames = storage_ns::load_file(arguments.name, arguments);
            return frames;
        } else {
            return create_frames_from_video(arguments);
        }
    }
}